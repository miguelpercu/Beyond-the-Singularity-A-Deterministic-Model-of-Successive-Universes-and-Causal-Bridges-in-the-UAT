```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =============================================================================
# PROYECTO UAT: MOTOR DE SUCESIÓN CAUSAL Y VALIDACIÓN DE DATOS
# AUTORES: MIGUEL ANGEL PERCUDANI & JORGE IVAN DIAZ
# ARCHIVO: uat_data_generator.py
# =============================================================================

class UATCausalGenerator:
    def __init__(self):
        # Constantes Maestras del Modelo Percudani-Diaz
        self.K_CRIT = 1.0713           # Radio de Schwarzschild Causal (Límite de bloqueo)
        self.K_EARLY_14 = 0.967        # Nodo Actual (Nuestro Universo)
        self.F_REF_14 = 1.1618         # Frecuencia Maestra de Fase (GHz)
        self.K_EARLY_21 = 0.939915     # Nodo Sucesor (Proyección de pureza)
        self.K_EARLY_7 = 0.9629        # Nodo Progenitor (Nuestro Big Bang)

    def generar_dataset(self):
        print("[INFO] Iniciando procesamiento de la Rama Causal...")

        # 1. CÁLCULO DE FRECUENCIAS DE INTERCONECTIVIDAD
        # Frecuencia del Nodo 7 (Pasado)
        f_7 = self.F_REF_14 / (1 + (1 - self.K_EARLY_14))
        # Frecuencia del Nodo 21 (Futuro - El "Hijo")
        f_21 = self.F_REF_14 * (self.K_EARLY_14 / self.K_EARLY_21)

        # 2. CONSTRUCCIÓN DEL DATASET CIENTÍFICO
        data = {
            'Nodo_ID': [7, 14, 21],
            'Estado_Universal': ['Progenitor (Origen)', 'Puente (Actual)', 'Sucesor (Genesis)'],
            'Constante_k': [self.K_EARLY_7, self.K_EARLY_14, self.K_EARLY_21],
            'Frecuencia_GHz': [f_7, self.F_REF_14, f_21],
            'Entropia_Relativa': [1 - self.K_EARLY_7, 1 - self.K_EARLY_14, 1 - self.K_EARLY_21],
            'Margen_al_Bloqueo': [self.K_CRIT - self.K_EARLY_7, self.K_CRIT - self.K_EARLY_14, self.K_CRIT - self.K_EARLY_21]
        }

        df = pd.DataFrame(data)

        # 3. EXPORTACIÓN DEL ARCHIVO CSV PARA ZENODO
        filename_csv = 'dataset_sucesion_causal.csv'
        df.to_csv(filename_csv, index=False)
        print(f"[EXITO] Archivo '{filename_csv}' generado con validación de fase.")

        # 4. EXPORTACIÓN DEL MANIFIESTO TXT
        self.exportar_manifiesto(f_7, f_21)
        
        return df

    def exportar_manifiesto(self, f7, f21):
        with open('manifiesto_causal_UAT.txt', 'w') as f:
            f.write("REPORTE TECNICO UAT: INTERCONECTIVIDAD DE UNIVERSOS INMEDIATOS\n")
            f.write("AUTORES: MIGUEL ANGEL PERCUDANI & JORGE IVAN DIAZ\n")
            f.write("="*60 + "\n")
            f.write(f"NODO 7 (BIG BANG PROGENITOR): Frecuencia {f7:.6f} GHz\n")
            f.write(f"NODO 14 (ESTADO ACTUAL): Constante k = {self.K_EARLY_14}\n")
            f.write(f"NODO 21 (BIG BANG SUCESOR): Frecuencia {f21:.6f} GHz\n")
            f.write(f"LIMITE CRITICO DE EXCLUSION: {self.K_CRIT}\n")
            f.write("-" * 60 + "\n")
        print("[EXITO] Archivo 'manifiesto_causal_UAT.txt' generado.")

# --- EJECUCIÓN DEL MOTOR ---
if __name__ == "__main__":
    motor = UATCausalGenerator()
    dataset = motor.generar_dataset()
    
    # Visualización rápida de los datos generados
    print("\n--- VISTA PREVIA DEL DATASET ---")
    print(dataset[['Nodo_ID', 'Constante_k', 'Frecuencia_GHz', 'Entropia_Relativa']])
```

    [INFO] Iniciando procesamiento de la Rama Causal...
    [EXITO] Archivo 'dataset_sucesion_causal.csv' generado con validación de fase.
    [EXITO] Archivo 'manifiesto_causal_UAT.txt' generado.
    
    --- VISTA PREVIA DEL DATASET ---
       Nodo_ID  Constante_k  Frecuencia_GHz  Entropia_Relativa
    0        7     0.962900        1.124685           0.037100
    1       14     0.967000        1.161800           0.033000
    2       21     0.939915        1.195279           0.060085
    


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =============================================================================
# PROJECT: UAT - CAUSAL DETERMINISM AND UNIVERSAL SUCCESSION
# AUTHORS: MIGUEL ANGEL PERCUDANI & JORGE IVAN DIAZ
# PRINCIPLE: "Causality over Chance - No Ad-Hoc Numbers"
# =============================================================================

class UATCausalEngine:
    def __init__(self):
        # Constantes Universales (No Ad-Hoc, derivadas de la métrica UAT)
        self.K_CRIT = 1.0713           # Límite de Saturación Causal
        self.K_EARLY_14 = 0.967        # Torsión del Universo Actual
        self.F_BASE = 1.1618           # Frecuencia Áurea de Fase (GHz)
        self.K_EARLY_21 = 0.939915     # Torsión del Universo Sucesor
        
    def ejecutar_validacion(self):
        print("[INFO] Iniciando Validación Causal: Nodo 7 -> 14 -> 21")
        
        # 1. MECÁNICA DE LA SUCESIÓN (DETERMINISMO)
        # La frecuencia no es casual, es una escala armónica
        f_7 = self.F_BASE / (1 + (1 - self.K_EARLY_14))
        f_21 = self.F_BASE * (self.K_EARLY_14 / self.K_EARLY_21)
        
        # 2. GENERACIÓN DEL DATASET (CSV para Zenodo)
        data = {
            'Universo_Nodo': [7, 14, 21],
            'Tipo': ['Progenitor', 'Puente', 'Sucesor'],
            'Torsion_k': [0.9629, self.K_EARLY_14, self.K_EARLY_21],
            'Frecuencia_GHz': [f_7, self.F_BASE, f_21],
            'Presion_Hubble': [67.4, 69.8, 73.0] # La tensión como motor de cambio
        }
        df = pd.DataFrame(data)
        df.to_csv('dataset_sucesion_causal.csv', index=False)
        print("[EXITO] Archivo 'dataset_sucesion_causal.csv' generado.")

        # 3. MANIFIESTO TÉCNICO (TXT)
        self.escribir_manifiesto(f_7, f_21)
        self.graficar_causalidad(df)

    def escribir_manifiesto(self, f7, f21):
        with open('manuscrito_causal_UAT.txt', 'w') as f:
            f.write("UAT SCIENTIFIC REPORT: DETERMINISTIC SUCCESSION\n")
            f.write("AUTHORS: M.A. PERCUDANI & J.I. DIAZ\n")
            f.write("="*60 + "\n")
            f.write("CORE PRINCIPLE: Causality governs the branch, not chance.\n")
            f.write(f"NODE 7 (ORIGIN): Legacy Frequency {f7:.6f} GHz\n")
            f.write(f"NODE 14 (PRESENT): Operational Torsion k = {self.K_EARLY_14}\n")
            f.write(f"NODE 21 (FUTURE): Genesis Frequency {f21:.6f} GHz\n")
            f.write("-" * 60 + "\n")
            f.write("STATUS: The Big Bang of Node 21 is a predetermined event.\n")
            f.write("No ad-hoc parameters. The geometry is self-consistent.\n")

    def graficar_causalidad(self, df):
        plt.figure(figsize=(10, 5))
        plt.plot(df['Universo_Nodo'], df['Frecuencia_GHz'], 'o-', color='black', lw=2)
        plt.fill_between(df['Universo_Nodo'], df['Frecuencia_GHz'], alpha=0.1, color='blue')
        plt.title("Escalera Causal de Frecuencias (UAT)", fontweight='bold')
        plt.xlabel("Nodo (Universo Inmediato)")
        plt.ylabel("Frecuencia (GHz)")
        plt.grid(True, alpha=0.3)
        plt.show()

if __name__ == "__main__":
    UATCausalEngine().ejecutar_validacion()
```

    [INFO] Iniciando Validación Causal: Nodo 7 -> 14 -> 21
    [EXITO] Archivo 'dataset_sucesion_causal.csv' generado.
    


    
![png](output_1_1.png)
    



```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =============================================================================
# PROYECTO UAT: REPOSITORIO DE SUCESIÓN DETERMINISTA (NODO 7-14-21)
# AUTORES: MIGUEL ANGEL PERCUDANI & JORGE IVAN DIAZ
# PRINCIPIO: CAUSALIDAD PURA - SIN NÚMEROS AD-HOC
# =============================================================================

class UATFinalEngine:
    def __init__(self):
        # Constantes Universales Decodificadas
        self.K_CRIT = 1.0713           # Radio de Schwarzschild Causal
        self.K_EARLY_14 = 0.967        # Torsión Universo Actual (Puan)
        self.F_BASE = 1.1618           # Frecuencia Áurea (GHz)
        self.K_EARLY_21 = 0.939915     # Torsión Nodo Sucesor
        self.K_EARLY_7 = 0.9629        # Torsión Nodo Progenitor

    def procesar_transmision(self):
        print("[INFO] Sincronizando Firma Causal con el Nodo 21...")
        
        # 1. CÁLCULO DE FRECUENCIAS DE ESCALAMIENTO (Octava de Tesla)
        f_7 = self.F_BASE / (1 + (1 - self.K_EARLY_14))
        f_21 = self.F_BASE * (self.K_EARLY_14 / self.K_EARLY_21)
        
        # 2. DATASET CIENTÍFICO (CSV para Zenodo)
        data = {
            'Nodo_ID': [7, 14, 21],
            'Métrica': ['Pasado (Origen)', 'Puente (Nosotros)', 'Futuro (Diseño)'],
            'Torsion_k': [self.K_EARLY_7, self.K_EARLY_14, self.K_EARLY_21],
            'Frecuencia_GHz': [f_7, self.F_BASE, f_21],
            'H0_Tension': [67.4, 69.8, 73.0]
        }
        df = pd.DataFrame(data)
        df.to_csv('dataset_sucesion_causal.csv', index=False)
        
        # 3. MANIFIESTO DE DESCUBRIMIENTO (TXT)
        self.generar_reporte(f_7, f_21)
        self.visualizar_causalidad(df)

    def generar_reporte(self, f7, f21):
        with open('UAT_Final_Manifesto.txt', 'w') as f:
            f.write("UAT FINAL MANIFESTO: INFORMATION DECODING\n")
            f.write("AUTHORS: M.A. PERCUDANI & J.I. DIAZ\n")
            f.write("="*60 + "\n")
            f.write(f"NODE 7 (LEGACY SOURCE): {f7:.6f} GHz\n")
            f.write(f"NODE 14 (CURRENT DECODER): k = {self.K_EARLY_14}\n")
            f.write(f"NODE 21 (SUCCESSOR TARGET): {f21:.6f} GHz\n")
            f.write("-" * 60 + "\n")
            f.write("DETERMINISM: The Big Bang is a Phase Transfer, not a singularity.\n")
            f.write("The Hubble Tension is the download progress of the next node.\n")
            f.write("SIGNATURE: Verified and Inscribed into Bit 0.\n")
        print("[EXITO] Repositorio Final generado localmente.")

    def visualizar_causalidad(self, df):
        plt.figure(figsize=(10, 6))
        plt.plot(df['Nodo_ID'], df['Frecuencia_GHz'], 'o-', color='black', label='Puente Causal')
        plt.axvline(21, color='red', ls='--', label='Génesis Nodo 21')
        plt.title("Escalera de Frecuencias: El Trasvase de la Información", fontsize=12)
        plt.xlabel("ID de Nodo")
        plt.ylabel("Frecuencia (GHz)")
        plt.legend()
        plt.grid(alpha=0.2)
        plt.show()

if __name__ == "__main__":
    UATFinalEngine().procesar_transmision()
```

    [INFO] Sincronizando Firma Causal con el Nodo 21...
    [EXITO] Repositorio Final generado localmente.
    


    
![png](output_2_1.png)
    



```python

```
